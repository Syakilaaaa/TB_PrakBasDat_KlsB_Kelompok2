--
-- Database: `nyammeow_db`
--
DROP DATABASE IF EXISTS `nyammeow_db`;
CREATE DATABASE IF NOT EXISTS `nyammeow_db` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `nyammeow_db`;

-- --------------------------------------------------------

--
-- Table structure for table `detail_pesanan`
--

DROP TABLE IF EXISTS `detail_pesanan`;
CREATE TABLE `detail_pesanan` (
  `id` int(11) NOT NULL,
  `pesanan_id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `subtotal` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `detail_pesanan`
--

INSERT INTO `detail_pesanan` (`id`, `pesanan_id`, `menu_id`, `jumlah`, `subtotal`) VALUES
(1, 1, 10, 1, 22000),
(2, 1, 1, 1, 28000),
(3, 2, 4, 1, 35000),
(4, 3, 1, 1, 28000),
(5, 4, 4, 3, 105000),
(6, 5, 4, 1, 35000),
(7, 6, 1, 2, 56000),
(8, 6, 4, 1, 35000),
(9, 7, 9, 1, 25000),
(10, 7, 2, 1, 32000),
(11, 8, 1, 1, 28000);

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

DROP TABLE IF EXISTS `menu`;
CREATE TABLE `menu` (
  `id` int(11) NOT NULL,
  `nama_menu` varchar(100) NOT NULL,
  `kategori` enum('Makanan','Minuman') NOT NULL,
  `harga` int(11) NOT NULL,
  `gambar` varchar(255) DEFAULT 'default.jpg',
  `stok` int(11) DEFAULT 99
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`id`, `nama_menu`, `kategori`, `harga`, `gambar`, `stok`) VALUES
(1, 'Meow Chicken Rice', 'Makanan', 28000, 'default.jpg', 99),
(2, 'Tuna Fish Bowl', 'Makanan', 32000, 'default.jpg', 99),
(3, 'Salmon Purr-fect', 'Makanan', 38000, 'default.jpg', 99),
(4, 'Cat-lifornia Roll', 'Makanan', 35000, 'default.jpg', 99),
(5, 'Milk Meow-shake', 'Minuman', 15000, 'default.jpg', 99),
(6, 'Catpuccino', 'Minuman', 18000, 'default.jpg', 99),
(7, 'Whisker Tea', 'Minuman', 10000, 'default.jpg', 99),
(8, 'Purple Cat Juice', 'Minuman', 14000, 'default.jpg', 99),
(9, 'Nasi Goreng Meowkong', 'Makanan', 25000, 'default.jpg', 99),
(10, 'Mie Nyam-Nyam', 'Makanan', 22000, 'default.jpg', 99);

-- --------------------------------------------------------

--
-- Table structure for table `pesanan`
--

DROP TABLE IF EXISTS `pesanan`;
CREATE TABLE `pesanan` (
  `id` int(11) NOT NULL,
  `no_meja` int(11) NOT NULL,
  `nama_pemesan` varchar(100) NOT NULL,
  `total_harga` int(11) NOT NULL,
  `status` enum('Menunggu Pembayaran','Dibayar','Sedang Dimasak','Selesai') NOT NULL DEFAULT 'Menunggu Pembayaran',
  `catatan` text DEFAULT NULL,
  `metode_pembayaran` varchar(50) DEFAULT 'Cash',
  `waktu_dibayar` datetime DEFAULT NULL,
  `dikonfirmasi_oleh` varchar(100) DEFAULT NULL,
  `tanggal_pesan` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pesanan`
--

INSERT INTO `pesanan` (`id`, `no_meja`, `nama_pemesan`, `total_harga`, `status`, `catatan`, `metode_pembayaran`, `waktu_dibayar`, `dikonfirmasi_oleh`, `tanggal_pesan`) VALUES
(1, 6, 'kkkl', 50000, 'Selesai', '', 'Cash', '2026-06-12 16:02:51', NULL, '2026-06-12 08:54:55'),
(2, 4, 'lllqq', 35000, 'Selesai', '', 'QRIS', '2026-06-12 16:15:04', NULL, '2026-06-12 08:57:46'),
(3, 5, '33jsg', 28000, 'Sedang Dimasak', '', 'QRIS', '2026-06-12 20:48:58', NULL, '2026-06-12 09:11:43'),
(4, 5, 'hhhh', 105000, 'Sedang Dimasak', '', 'Cash', '2026-06-12 20:48:56', NULL, '2026-06-12 09:13:06'),
(5, 1, 'p[[[', 35000, 'Sedang Dimasak', '', 'Cash', '2026-06-12 20:48:25', NULL, '2026-06-12 12:20:59'),
(6, 1, 'kanyut', 91000, 'Sedang Dimasak', '', 'Cash', '2026-06-12 20:48:22', NULL, '2026-06-12 12:57:24'),
(7, 1, 'dhawbdhkawd', 57000, '', '', 'Cash', NULL, NULL, '2026-06-12 13:44:34'),
(8, 1, 'dajd', 28000, '', '', 'QRIS', NULL, NULL, '2026-06-12 13:47:26');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `detail_pesanan`
--
ALTER TABLE `detail_pesanan`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pesanan_id` (`pesanan_id`),
  ADD KEY `menu_id` (`menu_id`);

--
-- Indexes for table `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pesanan`
--
ALTER TABLE `pesanan`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `idx_tanggal` (`tanggal_pesan`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `detail_pesanan`
--
ALTER TABLE `detail_pesanan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `menu`
--
ALTER TABLE `menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `pesanan`
--
ALTER TABLE `pesanan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `detail_pesanan`
--
ALTER TABLE `detail_pesanan`
  ADD CONSTRAINT `detail_pesanan_ibfk_1` FOREIGN KEY (`pesanan_id`) REFERENCES `pesanan` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `detail_pesanan_ibfk_2` FOREIGN KEY (`menu_id`) REFERENCES `menu` (`id`);
